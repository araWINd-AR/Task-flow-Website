import React from "react";
import { Outlet } from "react-router-dom";
import Sidebar from "./components/Sidebar";
import TopBar from "./components/TopBar";

export default function Layout() {
  return (
    <div className="appShell">
      <Sidebar />
      <div className="appMain">
        <TopBar />
        <div className="pageWrap">
          <Outlet />
        </div>
      </div>
    </div>
  );
}
